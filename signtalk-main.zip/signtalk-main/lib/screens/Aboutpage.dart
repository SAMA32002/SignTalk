import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'About Page',
          style: TextStyle(
            color: Colors.white, // Set the text color to white
          ),
        ),
        backgroundColor:
            Color(0xFFF6c62ff), // Set your app bar background color here
        iconTheme:
            IconThemeData(color: Colors.white), // Set icon color to white
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'About Sign Language Translator',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Text(
                'Welcome to Sign Language Translator, a revolutionary application designed to bridge communication gaps for the deaf and hard-of-hearing community. Our mission is to make communication more accessible and inclusive by providing innovative translation solutions.',
                style: TextStyle(
                  fontSize: 16,
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Key Features:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Text(
                '1. Convert Sign Language to Written Words: Easily translate sign language gestures into written text to facilitate better understanding.',
                style: TextStyle(
                  fontSize: 16,
                ),
              ),
              Text(
                '2. Educational Resources: Access a rich library of educational resources to learn and improve your sign language skills.',
                style: TextStyle(
                  fontSize: 16,
                ),
              ),
              Text(
                '3. Inclusive Communication: Enhance communication between individuals with different language abilities by using our intuitive translation tools.',
                style: TextStyle(
                  fontSize: 16,
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Contact Us',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Text(
                'We value your feedback! For any inquiries or suggestions, please contact us at:',
                style: TextStyle(
                  fontSize: 16,
                ),
              ),
              Text(
                'Email: Signlanguage011@hotmail.com',
                style: TextStyle(
                  fontSize: 16,
                ),
              ),
              Text(
                'Phone: +201016273403',
                style: TextStyle(
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
