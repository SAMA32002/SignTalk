import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

class TextToVoicePage extends StatefulWidget {
  const TextToVoicePage({Key? key}) : super(key: key);

  @override
  _TextToVoicePageState createState() => _TextToVoicePageState();
}

class _TextToVoicePageState extends State<TextToVoicePage> {
  final FlutterTts flutterTts = FlutterTts();
  TextEditingController textEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();
    initTts();
  }

  Future<void> initTts() async {
    await flutterTts.setLanguage('en-US'); // Set language (e.g., 'en-US')
    await flutterTts.setSpeechRate(0.4); // Set speech rate (1.0 is the default)
    await flutterTts.setVolume(3.0); // Set volume (1.0 is the default)
    await flutterTts.setPitch(4.0); // Set pitch (1.0 is the default)
  }

  Future<void> speak() async {
    await flutterTts.speak(textEditingController.text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Text To Voice',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        backgroundColor: Color(0xFFF6c62ff),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              child: Center(
                child: TextField(
                  controller: textEditingController,
                  maxLines: null,
                  keyboardType: TextInputType.multiline,
                  decoration: InputDecoration(
                    labelText: 'Enter Text',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    contentPadding:
                        EdgeInsets.all(20), // Adjust text field size
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: speak,
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 16.0),
                child: Text(
                  'Speak',
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
