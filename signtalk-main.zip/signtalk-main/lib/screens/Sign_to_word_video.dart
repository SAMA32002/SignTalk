import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:hello_world/main.dart';
import 'package:tflite_v2/tflite_v2.dart';

class Sign_to_word_video extends StatefulWidget {
  @override
  _Sign_to_word_video createState() => _Sign_to_word_video();
}

class _Sign_to_word_video extends State<Sign_to_word_video> {
  CameraImage? cameraImage;
  CameraController? cameraController;
  String output = '';
  String predictionText = 'Prediction:';

  @override
  void initState() {
    super.initState();
    loadCamera();
    loadmodel();
  }

  loadCamera() {
    cameraController = CameraController(cameras![0], ResolutionPreset.medium);
    cameraController!.initialize().then((value) {
      if (!mounted) {
        return;
      } else {
        setState(() {
          cameraController!.startImageStream((ImageStream) {
            setState(() {
              cameraImage = ImageStream;
              runModel();
            });
          });
        });
      }
    });
  }

  runModel() async {
    if (cameraImage != null) {
      var predictions = await Tflite.runModelOnFrame(
          bytesList: cameraImage!.planes.map((plane) {
            return plane.bytes;
          }).toList(),
          imageHeight: cameraImage!.height,
          imageWidth: cameraImage!.width,
          imageMean: 125.5,
          imageStd: 125.5,
          rotation: 90,
          numResults: 2,
          threshold: 0.1,
          asynch: true);
      predictions!.forEach((element) {
        setState(() {
          output = element['label'];
        });
      });
    }
  }

  loadmodel() async {
    await Tflite.loadModel(
        model: "images/model_unquant.tflite", labels: "images/labels.txt");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Sign To Word Video',
          style: TextStyle(
            color: Colors.white, // Set the text color to white
          ),
        ),
        backgroundColor:
            Color(0xFFF6c62ff), // Set your app bar background color here
        iconTheme:
            IconThemeData(color: Colors.white), // Set icon color to white
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(20),
            child: Container(
              height: MediaQuery.of(context).size.height * 0.7,
              width: MediaQuery.of(context).size.width,
              child: !cameraController!.value.isInitialized
                  ? Container()
                  : AspectRatio(
                      aspectRatio: cameraController!.value.aspectRatio,
                      child: CameraPreview(cameraController!),
                    ),
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  predictionText,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 30, // Adjust font size here
                    color: Color(0xFFF6C62FF), // Set color here
                  ),
                ),
                Text(
                  output,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 30, // Adjust font size here
                    color: Color(0xFFF6C62FF), // Set color here
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
