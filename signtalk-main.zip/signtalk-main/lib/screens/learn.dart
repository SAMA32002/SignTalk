import 'package:flutter/material.dart';

class LearnPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Learn A-Z',
          style: TextStyle(
            color: Colors.white, // Set the text color to white
          ),
        ),
        backgroundColor:
            Color(0xFFF6c62ff), // Set your app bar background color here
        iconTheme:
            IconThemeData(color: Colors.white), // Set icon color to white
      ),
      body: ListView(
        // Wrap the Column with a ListView
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment:
                  CrossAxisAlignment.start, // Align text to the left
              children: [
                Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start, // Align text to the left
                  children: [
                    Text(
                      'Alphabets...',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ), // Increase font size
                    ),
                    Image.asset(
                      'images/learn1.jpeg',
                      width: 420, // Adjust width as needed
                      height: 300, // Adjust height as needed
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start, // Align text to the left
                  children: [
                    Text(
                      'Numbers...',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ), // Increase font size
                    ),
                    Image.asset(
                      'images/learn2.jpeg',
                      width: 420, // Adjust width as needed
                      height: 300, // Adjust height as needed
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start, // Align text to the left
                  children: [
                    Text(
                      'Words...',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ), // Increase font size
                    ),
                    Image.asset(
                      'images/learn3.jpeg',
                      width: 420, // Adjust width as needed
                      height: 300, // Adjust height as needed
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start, // Align text to the left
                  children: [
                    Text(
                      'Words...',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ), // Increase font size
                    ),
                    Image.asset(
                      'images/learn4.jpeg',
                      width: 420, // Adjust width as needed
                      height: 300, // Adjust height as needed
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start, // Align text to the left
                  children: [
                    Text(
                      'Sentences...',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ), // Increase font size
                    ),
                    Image.asset(
                      'images/learn5.jpeg',
                      width: 420, // Adjust width as needed
                      height: 300, // Adjust height as needed
                    ),
                    Image.asset(
                      'images/learn6.jpeg',
                      width: 420, // Adjust width as needed
                      height: 300, // Adjust height as needed
                    ),
                    Image.asset(
                      'images/learn7.jpeg',
                      width: 420, // Adjust width as needed
                      height: 300, // Adjust height as needed
                    ),
                    Image.asset(
                      'images/learn8.jpeg',
                      width: 420, // Adjust width as needed
                      height: 150, // Adjust height as needed
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
