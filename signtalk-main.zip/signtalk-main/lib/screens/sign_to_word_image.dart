import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tflite_v2/tflite_v2.dart';

class SignToWordImage extends StatefulWidget {
  const SignToWordImage({Key? key}) : super(key: key);

  @override
  _SignToWordImageState createState() => _SignToWordImageState();
}

class _SignToWordImageState extends State<SignToWordImage> {
  final ImagePicker _picker = ImagePicker();
  XFile? _image;
  var _recognitions;

  @override
  void initState() {
    super.initState();
    loadModel().then((value) {
      setState(() {});
    });
  }

  Future<void> loadModel() async {
    await Tflite.loadModel(
      model: "images/model_unquant.tflite",
      labels: "images/labels.txt",
      useGpuDelegate: false,
      numThreads: 1, // defaults to 1
      isAsset: true,
    );
  }

  Future<void> pickImage(ImageSource source) async {
    try {
      final XFile? image = await _picker.pickImage(source: source);
      if (image != null) {
        setState(() {
          _image = image;
        });
        detectImage(File(image.path));
      }
    } catch (e) {
      print('Error picking image: $e');
    }
  }

  Future<void> detectImage(File image) async {
    int startTime = DateTime.now().millisecondsSinceEpoch;
    var recognitions = await Tflite.runModelOnImage(
      path: image.path,
      numResults: 6,
      threshold: 0.05,
      imageMean: 127.5,
      imageStd: 127.5,
    );
    setState(() {
      _recognitions = recognitions;
    });
    print("//////////////////////////////////////////////////");
    print(_recognitions);
    print("//////////////////////////////////////////////////");
    int endTime = DateTime.now().millisecondsSinceEpoch;
    print("Inference took ${endTime - startTime}ms");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Sign To Word Image',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        backgroundColor: Color(0xFFF6c62ff),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 10),
              Text(
                'Upload Your image Here',
                style: TextStyle(fontSize: 23),
              ),
              SizedBox(height: 5),
              GestureDetector(
                onTap: () async {
                  await pickImage(ImageSource.gallery);
                },
                child: Container(
                  height: 340,
                  width: double.infinity,
                  color: Color(0xFFFccccff),
                  child: _image != null
                      ? Image.file(
                          File(_image!.path),
                          fit: BoxFit.contain,
                        )
                      : Icon(
                          Icons.add,
                          size: 100,
                        ),
                ),
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: () async {
                      await pickImage(ImageSource.camera);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFFF6c62ff),
                      minimumSize: Size(150, 60),
                    ),
                    child: Text(
                      'Camera',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                      ),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      await pickImage(ImageSource.gallery);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFFF6c62ff),
                      minimumSize: Size(150, 60),
                    ),
                    child: Text(
                      'Gallery',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              if (_recognitions != null && _recognitions.isNotEmpty)
                Text(
                  'Prediction: ${_recognitions[0]['label']}',
                  style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFF6c62ff),
                    fontStyle: FontStyle.italic,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    Tflite.close();
    super.dispose();
  }
}
