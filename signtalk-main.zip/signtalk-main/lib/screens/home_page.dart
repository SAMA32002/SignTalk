import 'package:flutter/material.dart';
import 'package:hello_world/screens/Sign_to_word_video.dart';
import 'package:hello_world/screens/sign_to_word_image.dart';
import 'package:hello_world/screens/Aboutpage.dart';
import 'package:hello_world/screens/voice_to_text.dart';
import 'package:hello_world/screens/text_to_voice.dart';
import 'package:hello_world/screens/learn.dart';

class HomePage extends StatelessWidget {
  static String id = 'homepage';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.only(
                  top: 0,
                  left: 20,
                ),
                child: Text(
                  'Common Sign Languages',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.only(top: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          Image(
                            image: AssetImage('images/Rectangle 1.png'),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Everything is fine',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          Image(
                            image: AssetImage('images/Rectangle 2.png'),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'I do not know',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.only(top: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          Image(
                            image: AssetImage('images/Rectangle 3.png'),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Everything is fine',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          Image(
                            image: AssetImage('images/Rectangle 4.png'),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'I like it',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.only(
                  top: 30,
                  left: 20,
                ),
                child: Text(
                  'Choose The Way You Want To Translate:',
                  style: TextStyle(
                    fontSize: 19.5,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (BuildContext context) {
                                    return SignToWordImage();
                                  },
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFFF6c62ff),
                              minimumSize: Size(
                                  double.infinity, 80), // Increased button size
                            ),
                            child: Text(
                              'Convert Sign To Word (Image)',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 17.3, // Increased font size
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 20),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (BuildContext context) {
                                    return Sign_to_word_video();
                                  },
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFFF6c62ff),
                              minimumSize: Size(
                                  double.infinity, 80), // Increased button size
                            ),
                            child: Text(
                              'Convert Sign To Word (Video)',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 17.3, // Increased font size
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (BuildContext context) {
                                    return VoiceToTextPage();
                                  },
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFFF6c62ff),
                              minimumSize: Size(
                                  double.infinity, 80), // Increased button size
                            ),
                            child: Text(
                              'Voice to Text',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20, // Increased font size
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 20),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (BuildContext context) {
                                    return TextToVoicePage();
                                  },
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFFF6c62ff),
                              minimumSize: Size(
                                  double.infinity, 80), // Increased button size
                            ),
                            child: Text(
                              'Text to Voice',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20, // Increased font size
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (BuildContext context) {
                                    return AboutPage();
                                  },
                                ),
                              );
                              print('Button 2 pressed');
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFFF6c62ff),
                              minimumSize: Size(
                                  double.infinity, 80), // Increased button size
                            ),
                            child: Text(
                              'About',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20, // Increased font size
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 20),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (BuildContext context) {
                                    return LearnPage();
                                  },
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFFF6c62ff),
                              minimumSize: Size(
                                  double.infinity, 80), // Increased button size
                            ),
                            child: Text(
                              'Learn A-Z',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20, // Increased font size
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
