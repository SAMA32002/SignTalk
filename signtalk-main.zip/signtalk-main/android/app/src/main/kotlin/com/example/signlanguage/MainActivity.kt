package com.example.signlanguage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
